CREATE TABLE order_table_1 (
	id INT NOT NULL PRIMARY KEY,
	value VARCHAR(256)
);

INSERT INTO order_table_1 (id, value) VALUES (1, 'order_table_1');