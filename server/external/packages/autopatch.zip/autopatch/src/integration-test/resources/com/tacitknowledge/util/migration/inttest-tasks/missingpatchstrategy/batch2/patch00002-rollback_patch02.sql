DROP TABLE core_table_1;
