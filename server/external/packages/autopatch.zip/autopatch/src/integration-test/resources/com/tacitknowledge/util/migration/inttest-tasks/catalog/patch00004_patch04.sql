CREATE TABLE catalog_table_1 (
	id INT NOT NULL PRIMARY KEY,
	value VARCHAR(256)
);

INSERT INTO catalog_table_1 (id, value) VALUES (1, 'catalog_table_1');