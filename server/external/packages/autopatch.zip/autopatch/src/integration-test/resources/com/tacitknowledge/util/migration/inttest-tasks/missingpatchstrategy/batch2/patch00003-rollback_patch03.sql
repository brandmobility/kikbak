DROP TABLE order_table_2;
