CREATE TABLE core_table_1 (
	id INT NOT NULL PRIMARY KEY,
	value VARCHAR(256)
);


INSERT INTO core_table_1 (id, value) VALUES (1, 'core_table_1');