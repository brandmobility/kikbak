   delete from user_role_assoc where application_user_id = '2';
   delete from user_role_assoc where application_user_id = '3';
   delete from user_role_assoc where application_user_id = '4';
	