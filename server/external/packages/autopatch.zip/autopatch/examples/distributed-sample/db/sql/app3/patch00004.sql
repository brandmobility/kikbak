CREATE TABLE baz (
	id INT NOT NULL PRIMARY KEY,
	value VARCHAR(256)
);

INSERT INTO baz(id, value) VALUES (1, 'foo');