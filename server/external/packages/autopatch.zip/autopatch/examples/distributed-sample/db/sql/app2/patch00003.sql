CREATE TABLE bar (
	id INT NOT NULL PRIMARY KEY,
	value VARCHAR(256)
);

INSERT INTO bar(id, value) VALUES (1, 'foo');